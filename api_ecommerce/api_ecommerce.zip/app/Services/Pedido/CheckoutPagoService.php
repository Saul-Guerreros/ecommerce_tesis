<?php

namespace App\Services\Pedido;

use App\Models\Configuracion\ConfiguracionTienda;
use App\Models\Pedido\MetodoPago;
use App\Models\Pedido\PedidoTemporal;
use App\Models\Usuario;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class CheckoutPagoService
{
    public function datosIniciales(): array
    {
        $config = ConfiguracionTienda::actual();

        return [
            'metodos' => MetodoPago::activos()->orderBy('mpa_id')->get(),
            'datos_transferencia' => [
                'banco'   => $config->ctn_pago_banco,
                'titular' => $config->ctn_pago_banco_titular,
                'cuenta'  => $config->ctn_pago_banco_cuenta,
            ],
            'datos_billetera' => [
                'titular'    => $config->ctn_pago_tigo_titular,
                'numero'     => $config->ctn_pago_tigo_numero,
                'referencia' => $config->ctn_pago_tigo_referencia,
            ],
            'mensaje_efectivo' => $config->ctn_pago_efectivo_mensaje,
        ];
    }

    public function borrador(Usuario $usuario): ?array
    {
        return PedidoTemporal::where('ptm_usuid', $usuario->usu_id)->first()?->ptm_pago;
    }

    public function guardar(Usuario $usuario, string $mpaCodigo, ?UploadedFile $comprobante): array
    {
        $this->verificarFacturacionPrevia($usuario);

        $metodo = MetodoPago::porCodigo($mpaCodigo);
        $temporal = PedidoTemporal::where('ptm_usuid', $usuario->usu_id)->first();
        $yaTeniaComprobante = !empty($temporal?->ptm_pago['comprobante_temp'] ?? null);

        if ($metodo->mpa_requcom && !$comprobante && !$yaTeniaComprobante) {
            throw ValidationException::withMessages([
                'comprobante' => 'Este método de pago requiere adjuntar el comprobante.',
            ]);
        }

        return DB::transaction(function () use ($temporal, $metodo, $comprobante) {
            $rutaAnterior = $temporal->ptm_pago['comprobante_temp'] ?? null;

            $pago = [
                'mpa_codigo' => $metodo->mpa_codigo,
                'mpa_descri' => $metodo->mpa_descri,
                // archivo temporal: se migra a pago_comprobante real recién al confirmar el Paso 3
                'comprobante_temp' => $comprobante
                    ? $comprobante->store('comprobantes_temp', 'public')
                    : ($metodo->mpa_requcom ? $rutaAnterior : null),
            ];

            if ($comprobante && $rutaAnterior) {
                Storage::disk('public')->delete($rutaAnterior);
            }

            $temporal->update(['ptm_pago' => $pago]);

            return $pago;
        });
    }

    private function verificarFacturacionPrevia(Usuario $usuario): void
    {
        $temporal = PedidoTemporal::where('ptm_usuid', $usuario->usu_id)->first();

        if (!$temporal || empty($temporal->ptm_factura)) {
            throw ValidationException::withMessages([
                'mpa_codigo' => 'Completá primero los datos de facturación.',
            ]);
        }
    }
}