<?php

namespace App\Services\Pedido;

use App\Http\Resources\Carrito\CarritoResource;
use App\Models\Carrito\Carrito;
use App\Models\Compras\Stock;
use App\Models\Configuracion\Deposito;
use App\Models\Configuracion\Sucursal;
use App\Models\Pedido\DetallePedido;
use App\Models\Pedido\EstadoPago;
use App\Models\Pedido\EstadoPedido;
use App\Models\Pedido\MetodoPago;
use App\Models\Pedido\PagoComprobante;
use App\Models\Pedido\Pedido;
use App\Models\Pedido\PedidoEntrega;
use App\Models\Pedido\PedidoFacturacion;
use App\Models\Pedido\PedidoHistorialEstado;
use App\Models\Pedido\PedidoTemporal;
use App\Models\Usuario;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PedidoService
{
    private const CON_CARRITO = [
        'producto.publicacionWeb.imagenes',
        'producto.publicacionWeb.categoria',
        'producto.stock',
        'producto.tipoIva',
    ];

    // ---------- Paso 3: GET (resumen) ----------

    public function datosConfirmacion(Usuario $usuario): array
    {
        $temporal = $this->temporalCompleto($usuario);
        $carritoItems = $this->carritoDelUsuario($usuario);

        return [
            'items'       => CarritoResource::collection($carritoItems),
            'entrega'     => $temporal->ptm_entrega,
            'facturacion' => $temporal->ptm_factura,
            'pago'        => $temporal->ptm_pago,
            'resumen'     => $this->resumen($carritoItems, $temporal->ptm_entrega),
        ];
    }

    // ---------- Paso 3: POST (Confirmar Pedido) ----------

    public function confirmar(Usuario $usuario): Pedido
    {
        $temporal = $this->temporalCompleto($usuario);
        $carritoItems = $this->carritoDelUsuario($usuario);

        $cliente = $usuario->persona->cliente;
        abort_if(!$cliente, 422, 'Tu cuenta todavía no tiene un perfil de cliente asociado.');

        $entrega     = $temporal->ptm_entrega;
        $facturacion = $temporal->ptm_factura;
        $pago        = $temporal->ptm_pago;
        $metodo      = MetodoPago::porCodigo($pago['mpa_codigo']);
        $resumen     = $this->resumen($carritoItems, $entrega);

        return DB::transaction(function () use (
            $usuario, $cliente, $carritoItems, $entrega, $facturacion, $pago, $metodo, $resumen, $temporal
        ) {
            $pedido = Pedido::create([
                'ped_cliid'  => $cliente->cli_id,
                'ped_subtot' => $resumen['subtotal'],
                'ped_impues' => $resumen['impuestos'],
                'ped_cosenv' => $resumen['costo_envio'],
                'ped_total'  => $resumen['total'],
                'ped_tenid'  => $entrega['ten_id'],
                'ped_sucid'  => $entrega['suc_id'] ?? null,
                'ped_mpaid'  => $metodo->mpa_id,
                'ped_estid'  => EstadoPedido::porCodigo(EstadoPedido::PENDIENTE)->est_id,
                'ped_epaid'  => EstadoPago::porCodigo(EstadoPago::PENDIENTE)->epa_id,
            ]);

            // Numeración simple basada en el correlativo real del pedido.
            $pedido->update([
                'ped_numero' => 'PED-' . date('Y') . '-' . str_pad((string) $pedido->ped_id, 6, '0', STR_PAD_LEFT),
            ]);

            $this->crearDetalle($pedido, $carritoItems);
            $this->crearEntrega($pedido, $entrega);
            $this->crearFacturacion($pedido, $facturacion);
            $this->reservarStock($carritoItems, $entrega);

            PedidoHistorialEstado::create([
                'peh_pedid'  => $pedido->ped_id,
                'peh_usuid'  => $usuario->usu_id,
                'peh_tipo'   => 'PEDIDO',
                'peh_estant' => null,
                'peh_estid'  => $pedido->ped_estid,
                'peh_coment' => 'Pedido creado',
            ]);

            if ($metodo->mpa_requcom && !empty($pago['comprobante_temp'])) {
                PagoComprobante::create([
                    'pco_pedid'  => $pedido->ped_id,
                    'pco_archiv' => $pago['comprobante_temp'],
                    'pco_verifi' => false,
                ]);
            }

            // El comprobante NO se borra de disco: pago_comprobante.pco_archiv
            // ahora es su referencia definitiva.

            // Solo se vacia la modalidad contado: el carrito a credito
            // queda intacto para su propio flujo.
            Carrito::where('car_idusu', $usuario->usu_id)
            ->where(function ($q) {
                $q->whereNull('car_modpag')->orWhere('car_modpag', 'contado');
            })
            ->delete();

            $temporal->delete();

            return $pedido->fresh();
        });
    }

    // ---------- Helpers ----------

    private function temporalCompleto(Usuario $usuario): PedidoTemporal
    {
        $temporal = PedidoTemporal::where('ptm_usuid', $usuario->usu_id)->first();

        if (!$temporal || empty($temporal->ptm_entrega)) {
            throw ValidationException::withMessages(['entrega' => 'Completá primero los datos de entrega.']);
        }
        if (empty($temporal->ptm_factura)) {
            throw ValidationException::withMessages(['facturacion' => 'Completá primero los datos de facturación.']);
        }
        if (empty($temporal->ptm_pago)) {
            throw ValidationException::withMessages(['pago' => 'Completá primero el método de pago.']);
        }

        return $temporal;
    }

        private function carritoDelUsuario(Usuario $usuario): Collection
    {
        $items = Carrito::where('car_idusu', $usuario->usu_id)
            ->where(function ($q) {
                // Este checkout ("Finalizar Compra") es SOLO para la modalidad
                // contado. Los items a credito pertenecen al flujo separado
                // "Solicitar Credito" y no deben leerse ni facturarse aca.
                $q->whereNull('car_modpag')->orWhere('car_modpag', 'contado');
            })
            ->with(self::CON_CARRITO)
            ->get();

        if ($items->isEmpty()) {
            throw ValidationException::withMessages(['carrito' => 'No tenés productos al contado en tu carrito.']);
        }

        return $items;
    }

    private function resumen(Collection $carritoItems, array $entrega): array
    {
        $subtotal = (float) $carritoItems->sum('car_total');

        $impuestos = (float) $carritoItems->sum(
            fn ($i) => $i->producto ? $i->producto->ivaIncluidoEn((float) $i->car_total) : 0.0
        );

        $costoEnvio = (float) ($entrega['costo_envio'] ?? 0);

        return [
            'subtotal'    => $subtotal,
            'impuestos'   => $impuestos,
            'costo_envio' => $costoEnvio,
            'total'       => $subtotal + $costoEnvio,
        ];
    }

    private function crearDetalle(Pedido $pedido, Collection $carritoItems): void
    {
        foreach ($carritoItems as $item) {
            $producto    = $item->producto;
            $descripcion = $producto?->publicacionWeb?->pub_titulo ?? $producto?->prd_descri ?? 'Producto';

            DetallePedido::create([
                'dpd_pedid'      => $pedido->ped_id,
                'dpd_prdid'      => $item->car_idpro,
                'dpd_descri'     => $descripcion,
                'dpd_cantid'     => $item->car_cantid,
                'dpd_precio'     => $item->car_precio,
                'dpd_subtot'     => $item->car_subtot,
                'dpd_total'      => $item->car_total,
                'dpd_iva'        => $producto ? $producto->ivaIncluidoEn((float) $item->car_total) : 0,
                'dpd_modpag'     => $item->car_modpag ?? 'contado',
                'dpd_numcuo'     => $item->car_numcuo,
                'dpd_recargopct' => $item->car_recargopct,
                'dpd_montocuo'   => $item->car_montocuo,
            ]);
        }
    }

    private function crearEntrega(Pedido $pedido, array $e): void
    {
        PedidoEntrega::create([
            'pen_pedid'      => $pedido->ped_id,
            'pen_tenid'      => $e['ten_id'],
            'pen_sucid'      => $e['suc_id'] ?? null,
            'pen_dirid'      => $e['dir_id'] ?? null,
            'pen_nrodoc'     => $e['rec_nrodoc'],
            'pen_nombre'     => $e['rec_nombre'],
            'pen_apelli'     => $e['rec_apelli'],
            'pen_telef'      => $e['rec_telef'] ?? null,
            'pen_departa'    => $e['departamento'] ?? null,
            'pen_ciudad'     => $e['ciudad'] ?? ($e['suc_ciudad'] ?? null),
            'pen_barrio'     => $e['barrio'] ?? null,
            'pen_calle'      => $e['calle'] ?? null,
            'pen_nrocasa'    => $e['nrocasa'] ?? null,
            'pen_referencia' => $e['referencia'] ?? null,
        ]);
    }

    private function crearFacturacion(Pedido $pedido, array $f): void
    {
        PedidoFacturacion::create([
            'pfa_pedid'    => $pedido->ped_id,
            'pfa_tipodoc'  => $f['tipo_documento'],
            'pfa_dfiid'    => $f['dfi_id'] ?? null,
            'pfa_nrodoc'   => $f['pfa_nrodoc'],
            'pfa_raznom'   => $f['pfa_raznom'],
            'pfa_telefono' => $f['pfa_telefono'] ?? null,
            'pfa_correo'   => $f['pfa_correo'] ?? null,
            'pfa_recibe'   => $f['pfa_recibe'],
        ]);
    }

    /**
     * Reserva (sto_reserv), no descuenta (sto_cantid): el descuento
     * definitivo y el movimiento_stock 'S' quedan para PagoService, cuando
     * el admin confirma el pago (fuera del alcance de este paso).
     * lockForUpdate() evita que dos confirmaciones simultáneas sobrevendan
     * la última unidad.
     */
    private function reservarStock(Collection $carritoItems, array $entrega): void
    {
        $deposito = $this->resolverDeposito($entrega);

        foreach ($carritoItems as $item) {
            $producto = $item->producto;

            if (!$producto || !$producto->prd_afestk) {
                continue; // producto que no controla stock
            }

            abort_if(!$deposito, 422, 'No se pudo determinar el depósito de despacho.');

            $stock = Stock::where('sto_prdid', $producto->prd_id)
                ->where('sto_depid', $deposito->dpo_id)
                ->lockForUpdate()
                ->first();

            $disponible = $stock ? ((float) $stock->sto_cantid - (float) $stock->sto_reserv) : 0.0;

            if ($disponible < (float) $item->car_cantid) {
                throw ValidationException::withMessages([
                    'stock' => "No hay stock suficiente de \"{$producto->prd_descri}\" para completar el pedido.",
                ]);
            }

            $stock->increment('sto_reserv', (float) $item->car_cantid);
        }
    }

    /**
     * Resolución simplificada del depósito de despacho: el principal de la
     * sucursal de retiro elegida, o el de la sucursal principal de la
     * empresa cuando es envío a domicilio. La resolución multi-sucursal
     * por stock y tarifa (Parte 2 del checkout) queda para una etapa
     * posterior — mismo TODO ya anotado en CheckoutEntregaService.
     */
    private function resolverDeposito(array $entrega): ?Deposito
    {
        $sucursalId = $entrega['suc_id'] ?? Sucursal::where('suc_princi', 1)->value('suc_id');

        if (!$sucursalId) {
            return null;
        }

        return Deposito::where('dpo_sucid', $sucursalId)->where('dpo_princi', 1)->first();
    }
}