<?php

namespace App\Http\Controllers\Credito;

use App\Http\Controllers\Controller;
use App\Http\Requests\Venta\DeclararPagoCuotaRequest;
use App\Http\Resources\Venta\MiCuotaResource;
use App\Models\Pedido\Pedido;
use App\Models\Venta\CtaCobrar;
use App\Models\Venta\CuotaPago;
use App\Services\Venta\CuotaPagoService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

/**
 * "Mis Cuotas": el cliente ve el cronograma de su pedido a credito y
 * declara el pago de una cuota.
 *
 * Declarar NO salda nada: deja el pago a la espera de verificacion. La
 * cuota pasa a COBRADA cuando el admin registra el cobro desde Cuentas
 * por Cobrar.
 */
class MisCuotasController extends Controller
{
    public function __construct(private CuotaPagoService $service)
    {
    }

    /** GET /api/tienda/pedidos/{numero}/cuotas */
    public function index(Request $request, string $numero): JsonResponse
    {
        $pedido = $this->pedidoDelCliente($request, $numero);

        if (!$pedido) {
            return response()->json(['message' => 'Pedido no encontrado'], 404);
        }

        if (!$pedido->esDeCredito()) {
            return response()->json(['message' => 'Este pedido no es a crédito.'], 409);
        }

        $factura = $pedido->factura()->first();

        // Sin factura todavia no hay deuda: solo el aviso informativo.
        if (!$factura) {
            return response()->json([
                'facturado' => false,
                'cuotas'    => [],
                'resumen'   => null,
            ], 200);
        }

        $cuotas = CtaCobrar::with([
            'pagoVigente.metodoPago',
            'pagoVigente.estadoPago',
            'pagoVigente.motivoRechazo',
            'pagoVigente.comprobante',
        ])
            ->where('cco_venid', $factura->ven_id)
            ->orderBy('cco_nrocuo')
            ->get();

        $pendientes = $cuotas->where('cco_estado', CtaCobrar::ESTADO_PENDIENTE);

        return response()->json([
            'facturado' => true,
            'factura' => [
                'numero' => $factura->ven_nrodoc,
                'fecha'  => $factura->ven_fchaem,
                'total'  => round((float) $factura->ven_total, 2),
            ],
                       'cuotas'  => MiCuotaResource::collection($cuotas),
            // Van acá y no en otra llamada: la config de pago del pedido
            // está pensada para un pedido pendiente, y éste ya se entregó.
            'metodos' => DB::table('metodo_pago')
                ->where('mpa_estado', 1)
                ->whereNotIn('mpa_codigo', ['CONTRAENTREGA', 'CHEQUE'])
                ->orderBy('mpa_descri')
                ->get(['mpa_id', 'mpa_codigo', 'mpa_descri', 'mpa_requcom']),
            'resumen' => [
                'total_cuotas'  => $cuotas->count(),
                'cobradas'      => $cuotas->where('cco_estado', CtaCobrar::ESTADO_COBRADA)->count(),
                'saldo'         => round((float) $pendientes->sum('cco_saldo'), 2),
                'proximo_venc'  => $pendientes->min('cco_vencim')?->format('Y-m-d'),
            ],
        ], 200);
    }

       /** POST /api/tienda/cuotas/pagar */
    public function pagar(DeclararPagoCuotaRequest $request): JsonResponse
    {
        $datos  = $request->validated();
        $cuotas = $datos['cuotas'];

        // Guarda de pertenencia: todas tienen que ser del cliente.
        foreach ($cuotas as $id) {
            if (!$this->cuotaDelCliente($request, (int) $id)) {
                return response()->json(['message' => 'Cuota no encontrada'], 404);
            }
        }

        $this->service->declarar($cuotas, $datos, $request->file('comprobante'));

        return response()->json([
            'message' => 'Recibimos tu pago. Lo vamos a verificar y te avisamos.',
        ], 201);
    }

    /** POST /api/tienda/cuotas/pagos/{pago}/comprobante */
    public function reemplazarComprobante(Request $request, int $pago): JsonResponse
    {
        $request->validate([
            'comprobante' => ['required', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
        ]);

        $registro = CuotaPago::with('detalle')->find($pago);

        if (!$registro || !$this->pagoDelCliente($request, $registro)) {
            return response()->json(['message' => 'Pago no encontrado'], 404);
        }

        $this->service->reemplazarComprobante($registro, $request->file('comprobante'));

        return response()->json([
            'message' => 'Comprobante enviado. Lo vamos a verificar.',
        ], 200);
    }

    /** GET /api/tienda/cuotas/pagos/{pago}/comprobante */
    public function verComprobante(Request $request, int $pago)
    {
        $registro = CuotaPago::with('comprobante', 'detalle')->find($pago);

        if (!$registro || !$this->pagoDelCliente($request, $registro)) {
            abort(404, 'Pago no encontrado');
        }

        $archivo = $registro->comprobante?->ccm_archiv;

        if (!$archivo || !Storage::disk('local')->exists($archivo)) {
            abort(404, 'Comprobante no disponible');
        }

        return Storage::disk('local')->response($archivo);
    }

// ---------- Guardas de pertenencia ----------

    private function clienteId(Request $request): ?int
    {
        $usuario = $request->user();
        $usuario?->loadMissing('persona.cliente');

        return $usuario?->persona?->cliente?->cli_id;
    }

    private function pedidoDelCliente(Request $request, string $numero): ?Pedido
    {
        $cliId = $this->clienteId($request);

        if (!$cliId) {
            return null;
        }

        return Pedido::where('ped_numero', $numero)
            ->where('ped_cliid', $cliId)
            ->first();
    }

    private function cuotaDelCliente(Request $request, int $ccoId): ?CtaCobrar
    {
        $cliId = $this->clienteId($request);

        if (!$cliId) {
            return null;
        }

        return CtaCobrar::where('cco_id', $ccoId)
            ->whereHas('venta', fn ($q) => $q->where('ven_cliid', $cliId))
            ->first();
    }

    /** La declaración es del cliente si todas sus cuotas lo son. */
    private function pagoDelCliente(Request $request, CuotaPago $pago): bool
    {
        foreach ($pago->detalle as $linea) {
            if (!$this->cuotaDelCliente($request, (int) $linea->cpd_ccoid)) {
                return false;
            }
        }

        return $pago->detalle->isNotEmpty();
    }
}