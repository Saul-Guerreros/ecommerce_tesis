<?php

namespace App\Http\Controllers\Pedido;

use App\Http\Controllers\Controller;
use App\Http\Requests\Pedido\PagoPedidoRequest;
use App\Http\Resources\Pedido\MetodoPagoResource;
use App\Http\Resources\Pedido\ResultadoPagoResource;
use App\Models\Usuario;
use App\Services\Pedido\PagoPedidoService;
use Illuminate\Http\JsonResponse;

/**
 * Paso 3 del checkout: pago de un pedido que ya existe.
 *
 * Se separa de CheckoutController a propósito. Los pasos 1 y 2 operan
 * sobre un borrador del usuario (pedido_temporal) y no tienen recurso
 * propio; acá el recurso es un pedido concreto, identificado por su número
 * en la URL. Eso es lo que hace que la pantalla sea reanudable: el cliente
 * puede cerrar el navegador y volver al link después, sin depender de
 * ningún borrador ni de que el carrito siga lleno.
 */
class PagoPedidoController extends Controller
{
    public function __construct(
        private PagoPedidoService $servicio,
    ) {
        $this->middleware('auth:api');
    }

    /**
     * Datos de la pantalla de pago: el pedido a pagar y las formas de pago
     * de la tienda.
     *
     * Devuelve 422 si el pedido ya fue pagado o venció; el frontend usa esa
     * respuesta para mandar al cliente a la pantalla de resultado o a
     * "Mis pedidos" en vez de mostrar un formulario inútil.
     */
    public function config(string $numero): JsonResponse
    {
        $usuario = $this->clienteAutenticado();
        $pedido  = $this->servicio->pedidoPagable($usuario, $numero);
        $datos   = $this->servicio->datosIniciales();

        return response()->json([
            'pedido' => [
                'ped_numero' => $pedido->ped_numero,
                'ped_total'  => (float) $pedido->ped_total,
                'ped_creado' => $pedido->ped_creado,
                'ped_vence'  => $pedido->ped_vence,
            ],
            'metodos'             => MetodoPagoResource::collection($datos['metodos']),
            'datos_transferencia' => $datos['datos_transferencia'],
            'datos_billetera'     => $datos['datos_billetera'],
            'mensaje_efectivo'    => $datos['mensaje_efectivo'],
        ], 200);
    }

    /**
     * Registra el pago declarado por el cliente.
     *
     * 201: se creó un recurso nuevo (las filas de pedido_pago). Devuelve ya
     * el resultado armado para que el frontend no tenga que hacer un GET
     * extra apenas navega a la pantalla final.
     */
    public function registrar(PagoPedidoRequest $request, string $numero): JsonResponse
    {
        $usuario = $this->clienteAutenticado();
        $pedido  = $this->servicio->registrar($usuario, $numero, $request->validated());

        return response()->json([
            'message' => $request->esDividido()
                ? 'Pagos registrados.'
                : 'Pago registrado.',
            'data'    => new ResultadoPagoResource($pedido),
        ], 201);
    }

    /**
     * Pantalla final (los 3 casos). Vive en su propia ruta y se resuelve
     * por número de pedido, así que sigue siendo válida de forma
     * permanente: el cliente puede recargarla o volver con el botón del
     * navegador sin encontrarse una página muerta.
     */
    public function resultado(string $numero): JsonResponse
    {
        $usuario = $this->clienteAutenticado();
        $pedido  = $this->servicio->pedidoConPago($usuario, $numero);

        return response()->json([
            'data' => new ResultadoPagoResource($pedido),
        ], 200);
    }

    private function clienteAutenticado(): Usuario
    {
        $usuario = auth('api')->user();
        $usuario->loadMissing('rol', 'persona');

        abort_if($usuario->rol?->rol_descri !== 'Cliente', 403, 'Este recurso es exclusivo para clientes.');

        return $usuario;
    }
}