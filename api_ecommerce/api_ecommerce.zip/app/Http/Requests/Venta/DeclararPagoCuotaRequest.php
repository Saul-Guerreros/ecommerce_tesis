<?php

namespace App\Http\Requests\Venta;

use Illuminate\Foundation\Http\FormRequest;

class DeclararPagoCuotaRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'cuotas'      => ['required', 'array', 'min:1'],
            'cuotas.*'    => ['integer', 'distinct', 'exists:cta_cobrar,cco_id'],

            'cpa_mpaid'   => ['required', 'integer', 'exists:metodo_pago,mpa_id'],
            'cpa_nrotrx'  => ['nullable', 'string', 'max:50'],
            'cpa_banco'   => ['nullable', 'string', 'max:60'],
            'cpa_fechpag' => ['nullable', 'date', 'before_or_equal:today'],

            // Mismo límite y formatos que el comprobante del checkout.
            'comprobante' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
        ];
    }

    public function messages(): array
    {
        return [
            'cpa_mpaid.required'  => 'Elegí con qué método pagaste.',
            'comprobante.mimes'   => 'El comprobante debe ser JPG, PNG o PDF.',
            'comprobante.max'     => 'El comprobante no puede pesar más de 5 MB.',
            'cpa_fechpag.before_or_equal' => 'La fecha del pago no puede ser futura.',
        ];
    }
}