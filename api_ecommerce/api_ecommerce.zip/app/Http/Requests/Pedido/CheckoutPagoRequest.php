<?php

namespace App\Http\Requests\Pedido;

use App\Models\Pedido\MetodoPago;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CheckoutPagoRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'mpa_codigo'  => ['required', Rule::in([
                MetodoPago::TRANSFERENCIA,
                MetodoPago::BILLETERA_MOVIL,
                MetodoPago::CONTRAENTREGA,
            ])],
            'comprobante' => ['nullable', 'file', 'mimes:jpg,jpeg,png,pdf', 'max:5120'],
        ];
    }

    public function messages(): array
    {
        return [
            'mpa_codigo.required' => 'Elegí un método de pago.',
            'mpa_codigo.in'       => 'El método de pago seleccionado no es válido.',
            'comprobante.file'    => 'El comprobante debe ser un archivo válido.',
            'comprobante.mimes'   => 'El comprobante debe ser una imagen (jpg, png) o PDF.',
            'comprobante.max'     => 'El comprobante no puede superar los 5 MB.',
        ];
    }
}