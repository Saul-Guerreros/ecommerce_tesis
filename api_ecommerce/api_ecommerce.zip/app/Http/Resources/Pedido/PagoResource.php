<?php

namespace App\Http\Resources\Pedido;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class PagoResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        $p = $this->resource;

        return [
            'mpa_codigo'        => $p['mpa_codigo'],
            'mpa_descri'        => $p['mpa_descri'],
            'tiene_comprobante' => !empty($p['comprobante_temp']),
        ];
    }
}