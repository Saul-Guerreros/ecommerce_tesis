<?php

namespace App\Models\Pedido;

use App\Models\Usuario;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PedidoTemporal extends Model
{
    protected $table = 'pedido_temporal';
    protected $primaryKey = 'ptm_id';

    const CREATED_AT = 'ptm_creado';
    const UPDATED_AT = 'ptm_actual';

    public const PASO_ENTREGA = 1;
    public const PASO_FACTURACION = 2;
    public const PASO_CONFIRMACION = 3;

    protected $fillable = ['ptm_usuid', 'ptm_paso', 'ptm_entrega', 'ptm_factura', 'ptm_pago'];

    protected $casts = [
        'ptm_usuid'   => 'integer',
        'ptm_paso'    => 'integer',
        'ptm_entrega' => 'array',
        'ptm_factura' => 'array',
        'ptm_pago'    => 'array',
        'ptm_creado'  => 'datetime',
        'ptm_actual'  => 'datetime',
    ];

    public function usuario(): BelongsTo
    {
        return $this->belongsTo(Usuario::class, 'ptm_usuid', 'usu_id');
    }

    public function tieneEntrega(): bool
    {
        return !empty($this->ptm_entrega);
    }
}