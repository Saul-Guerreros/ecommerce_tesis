<?php

namespace App\Models\Pedido;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class PagoComprobante extends Model
{
    protected $table = 'pago_comprobante';
    protected $primaryKey = 'pco_id';
    public $timestamps = false;
    const CREATED_AT = 'pco_subido';

    protected $fillable = ['pco_pedid', 'pco_archiv', 'pco_verifi'];

    protected $casts = [
        'pco_verifi' => 'boolean',
    ];

    public function pedido(): BelongsTo
    {
        return $this->belongsTo(Pedido::class, 'pco_pedid', 'ped_id');
    }
}