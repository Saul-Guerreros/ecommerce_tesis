import { CommonModule } from '@angular/common';
import { Component, DestroyRef, afterNextRender, afterRender, inject } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { CarritoService } from '../../core/services/carrito.service';
import { AuthService } from '../../pages/auth/service/auth.service';
import { HomeService } from '../../pages/home/service/home.service';
import { CarritoOffcanvasComponent } from '../components/carrito-offcanvas/carrito-offcanvas.component';
// --- import nuevo ---
import { ConfirmacionCarritoComponent } from '../components/confirmacion-carrito/confirmacion-carrito.component';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [
    FormsModule,
    RouterModule,
    CommonModule,
    CarritoOffcanvasComponent,
    ConfirmacionCarritoComponent,
  ],  templateUrl: './header.component.html',
  styleUrl: './header.component.css',
})
export class HeaderComponent {

  categories_menus: any = [];
  currency: string = 'PYG';

  // TODO: reemplazar por datos reales desde un servicio (ej. homeService.brands())
  brands: any = [
    { id: 1, name: 'Apple', logo: 'assets/images/brands/apple.svg' },
    { id: 2, name: 'Samsung', logo: 'assets/images/brands/samsung.svg' },
    { id: 3, name: 'Sony', logo: 'assets/images/brands/sony.svg' },
    { id: 4, name: 'Microsoft', logo: 'assets/images/brands/microsoft.svg' },
    { id: 5, name: 'Intel', logo: 'assets/images/brands/intel.svg' },
    { id: 6, name: 'HP', logo: 'assets/images/brands/hp.svg' },
    { id: 7, name: 'LG', logo: 'assets/images/brands/lg.svg' },
    { id: 8, name: 'Lenovo', logo: 'assets/images/brands/lenovo.svg' },
    { id: 9, name: 'ASUS', logo: 'assets/images/brands/asus.svg' },
    { id: 10, name: 'Acer', logo: 'assets/images/brands/acer.svg' },
    { id: 11, name: 'Dell', logo: 'assets/images/brands/dell.svg' },
    { id: 12, name: 'Canon', logo: 'assets/images/brands/canon.svg' },
  ];

  isLoading: boolean = false;
  searchT: string = '';

  // ---------- Estado del carrito (patrón Observer) ----------
  // El header ya no conoce las filas del carrito ni los totales: lo único
  // que necesita es el número del badge. El detalle de los ítems, el
  // subtotal y todas las acciones (cantidad, actualizar, eliminar) pasaron
  // a CarritoOffcanvasComponent.
  //
  // Se cuentan UNIDADES y no filas: dos unidades de un producto más una de
  // otro son 3, no 2.
  totalUnidades: number = 0;

  private destroyRef = inject(DestroyRef);

  constructor(
    public homeService: HomeService,
    public cookieService: CookieService,
    public carritoService: CarritoService,
    public authService: AuthService
  ) {
    // Suscripción al derivado del estado central del carrito.
    // Va en el constructor (contexto de inyección) y se da de baja sola
    // con takeUntilDestroyed.
    this.carritoService.cantidadUnidades$
      .pipe(takeUntilDestroyed(this.destroyRef))
      .subscribe({
        next: (unidades) => (this.totalUnidades = unidades),
        error: (err) => {
          console.error('Error en el estado del carrito:', err);
          this.totalUnidades = 0;
        },
      });

    afterNextRender(() => {
      this.homeService.menus().subscribe({
        next: (resp: any) => {
          this.categories_menus = resp.categories_menus;
        },
        error: (err) => {
          console.error('No se pudieron cargar las categorías del menú:', err.message);
          this.categories_menus = [];
        },
      });

      this.currency = this.cookieService.get('currency') || 'PYG';

      // Sin condicionar a isLoggedIn(): cargar() ya decide internamente si
      // trae el carrito de la BD (usuario con sesión) o lo previsualiza
      // desde localStorage (invitado). El resultado entra al Subject vía
      // tap(), así que acá no hace falta asignar nada: la suscripción de
      // arriba actualiza el badge sola.
      this.carritoService.cargar().subscribe({
        error: (err) => console.error('No se pudo cargar el carrito:', err),
      });
    });

    afterRender(() => {
      setTimeout(() => {
        this.isLoading = true;
      }, 50);
    });
  }

  /** El usuario se lee de AuthService, no a través del carrito. */
  get user(): any {
    return this.authService.user;
  }

  logout() {
    this.authService.logout();
    setTimeout(() => {
      window.location.reload();
    }, 50);
  }

  getIconMenu(menu: any) {
    var miDiv: any = document.getElementById('icon-' + menu.id);
    miDiv.innerHTML = menu.icon;
    return '';
  }

  searchProduct() {
    window.location.href = '/productos-busqueda?search=' + this.searchT;
  }
}