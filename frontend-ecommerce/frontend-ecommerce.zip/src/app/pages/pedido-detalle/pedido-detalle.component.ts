import { CommonModule, CurrencyPipe, DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { PedidoDetalle } from '../../core/models/pedido-cliente.model';
import { PedidoClienteService } from '../../core/services/pedido-cliente.service';

/**
 * Detalle de un pedido dentro de "Mis Pedidos".
 *
 * Distinto de pedido-resultado (la pantalla que sigue justo después de
 * pagar): éste es de consulta general, para cualquier pedido en cualquier
 * estado, y se llega acá sólo desde el listado — no es parte del flujo
 * del checkout.
 */
@Component({
  selector: 'app-pedido-detalle',
  standalone: true,
  imports: [CommonModule, CurrencyPipe, DatePipe, RouterModule],
  templateUrl: './pedido-detalle.component.html',
  styleUrl: './pedido-detalle.component.css',
})
export class PedidoDetalleComponent implements OnInit {
  numero = '';
  pedido!: PedidoDetalle;
  cargando = true;

  constructor(
    private servicio: PedidoClienteService,
    private route: ActivatedRoute,
    private router: Router,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.numero = this.route.snapshot.paramMap.get('numero') ?? '';
    this.cargar();
  }

  private cargar(): void {
    this.cargando = true;

    this.servicio.detalle(this.numero).subscribe({
      next: (resp) => {
        this.pedido = resp.data;
        this.cargando = false;
      },
      error: (e) => {
        this.cargando = false;
        this.toastr.error(e.error?.message ?? 'No encontramos ese pedido.', 'Error');
        this.router.navigate(['/mis-pedidos'], { replaceUrl: true });
      },
    });
  }

  get esRetiro(): boolean {
    return this.pedido?.entrega?.modalidad === 'RETIRO';
  }

  restante(): string {
    if (!this.pedido?.ped_vence) return '';

    const faltan = new Date(this.pedido.ped_vence).getTime() - Date.now();
    if (faltan <= 0) return 'vencido';

    const horas = Math.floor(faltan / 3_600_000);
    const minutos = Math.floor((faltan % 3_600_000) / 60_000);

    return horas > 0 ? `${horas} h ${minutos} min` : `${minutos} min`;
  }

  pagarAhora(): void {
    this.router.navigate(['/proceso-de-pago/pago', this.numero]);
  }

  abrirComprobante(url: string | null): void {
    if (url) window.open(url, '_blank');
  }

  volver(): void {
    this.router.navigate(['/mis-pedidos']);
  }
}