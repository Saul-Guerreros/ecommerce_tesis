/**
 * "Mis Pedidos" — lado cliente.
 *
 * Tipos separados de checkout.model.ts a propósito: el checkout modela un
 * pedido que se está armando (borrador, pago en curso); éste modela un
 * pedido que ya existe y se está consultando. Son vistas distintas del
 * mismo recurso, no el mismo objeto.
 */

export type EstadoPedidoCodigo =
  | 'PENDIENTE' | 'EN_PREPARACION' | 'LISTO' | 'ENTREGADO' | 'CANCELADO';

export type EstadoPagoCodigo =
  | 'PENDIENTE_PAGO' | 'PENDIENTE' | 'CONFIRMADO' | 'RECHAZADO' | 'PARCIAL';

export type FiltroPedidos =
  | 'todos' | 'pendiente_pago' | 'en_proceso' | 'entregados' | 'cancelados';

export interface EstadoEtiquetado {
  codigo: string | null;
  descripcion: string | null;
}

// ---------- Listado ----------

export interface PedidoListaItem {
  ped_numero: string;
  ped_total: number;
  ped_creado: string;
  entrega: { codigo: string | null; etiqueta: string };
  estado_pedido: EstadoEtiquetado;
  estado_pago: EstadoEtiquetado;
  /** true -> mostrar el botón "Pagar ahora". Lo decide el backend. */
  pagable: boolean;
  ped_vence: string | null;
}

export interface PedidosPaginados {
  data: PedidoListaItem[];
  meta: { current_page: number; last_page: number; total: number };
}

// ---------- Detalle ----------

export interface ProductoPedido {
  dpd_id: number;
  prd_id: number;
  descripcion: string;
  cantidad: number;
  precio: number;
  iva_tasa: number;
  iva_monto: number;
  subtotal: number;
  total: number;
  modalidad: string;
}

export interface EntregaDetalle {
  modalidad: 'RETIRO' | 'ENVIO';
  receptor: string;
  sucursal?: { nombre: string | null; direccion: string | null; horario: string | null };
  direccion?: {
    calle: string | null; nro_casa: string | null; barrio: string | null;
    ciudad: string | null; departamento: string | null; referencia: string | null;
  };
}

export interface FacturacionDetalle {
  tipo_documento: string;
  nro_documento: string;
  razon_social: string;
  recibe_por: string;
}

export interface PagoDetalle {
  orden: number;
  metodo: string | null;
  monto: number;
  estado: string | null;
  estado_descri: string | null;
  tiene_comprobante: boolean;
  comprobante_url: string | null;
}

export interface PedidoDetalle {
  ped_numero: string;
  ped_creado: string;
  ped_vence: string | null;
  pagable: boolean;
  estado_pedido: EstadoEtiquetado;
  estado_pago: EstadoEtiquetado;
  entrega: EntregaDetalle | null;
  productos: ProductoPedido[];
  totales: { subtotal: number; impuestos: number; costo_envio: number; total: number };
  facturacion: FacturacionDetalle | null;
  pagos: PagoDetalle[];
}

// ---------- Banner de pendiente ----------

export interface PedidoPendiente {
  ped_numero: string;
  ped_total: number;
  ped_vence: string;
}