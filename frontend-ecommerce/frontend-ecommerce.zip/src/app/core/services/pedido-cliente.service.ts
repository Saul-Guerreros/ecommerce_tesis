import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { URL_SERVICIOS } from '../../config/config';
import {
  FiltroPedidos, PedidoDetalle, PedidoPendiente, PedidosPaginados,
} from '../models/pedido-cliente.model';

/**
 * "Mis Pedidos": lado cliente.
 *
 * Servicio aparte de CheckoutService y PagoPedidoService: estos dos
 * operan sobre UN pedido en curso (el borrador o el que se está pagando);
 * éste consulta el historial completo del cliente. Mezclar las tres cosas
 * en un solo servicio haría que un componente de sólo lectura (el
 * listado) dependiera de la lógica de escritura del checkout.
 */
@Injectable({ providedIn: 'root' })
export class PedidoClienteService {
  private readonly URL = `${URL_SERVICIOS}/tienda/pedidos`;

  constructor(private http: HttpClient) {}

  listar(filtro: FiltroPedidos = 'todos', page = 1): Observable<PedidosPaginados> {
    return this.http.get<PedidosPaginados>(this.URL, { params: { filtro, page } });
  }

  detalle(numero: string): Observable<{ data: PedidoDetalle }> {
    return this.http.get<{ data: PedidoDetalle }>(`${this.URL}/${numero}`);
  }

  /**
   * Para el banner del header. data es null cuando no hay ningún pedido
   * pendiente de pago: no es un error, el componente simplemente no
   * muestra nada.
   */
  pendiente(): Observable<{ data: PedidoPendiente | null }> {
    return this.http.get<{ data: PedidoPendiente | null }>(`${this.URL}/pendiente`);
  }
}