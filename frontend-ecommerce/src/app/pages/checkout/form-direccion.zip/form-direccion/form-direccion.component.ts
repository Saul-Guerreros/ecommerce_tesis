import { CommonModule } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import {
  CiudadCatalogo, DepartamentoCatalogo, Direccion,
} from '../../../core/models/direccion.model';
import { DireccionClienteService } from '../../../core/services/direccion-cliente.service';

const ALIAS_SUGERIDOS = ['Mi Casa', 'Mi Trabajo', 'Otro'];

@Component({
  selector: 'app-form-direccion',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './form-direccion.component.html',
})
export class FormDireccionComponent implements OnInit, OnChanges {

  @Input() visible = false;
  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() guardado = new EventEmitter<Direccion>();

  form!: FormGroup;
  alias = ALIAS_SUGERIDOS;

  departamentos: DepartamentoCatalogo[] = [];
  private ciudades: CiudadCatalogo[] = [];
  ciudadesFiltradas: CiudadCatalogo[] = [];

  guardando = false;

  constructor(
    private fb: FormBuilder,
    private direccionService: DireccionClienteService,
    private toastr: ToastrService,
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      alias_opcion:    ['Mi Casa', [Validators.required]],
      dir_alias:       ['Mi Casa', [Validators.required, Validators.maxLength(50)]],
      dep_id:          [null as number | null, [Validators.required]],
      dir_ciuid:       [null as number | null, [Validators.required]],
      dir_barrio:      ['', [Validators.required, Validators.maxLength(60)]],
      dir_calle:       ['', [Validators.required, Validators.maxLength(100)]],
      dir_nrocasa:     ['', [Validators.maxLength(45)]],
      dir_referencia:  ['', [Validators.maxLength(250)]],
      dir_predet:      [false],
    });

    this.direccionService.catalogos().subscribe({
      next: (resp) => {
        this.departamentos = resp.departamentos;
        this.ciudades = resp.ciudades;
      },
      error: () => this.toastr.error('No pudimos cargar los departamentos.', 'Error'),
    });
  }

  ngOnChanges(cambios: SimpleChanges): void {
    if (cambios['visible']?.currentValue === true && this.form) {
      this.form.reset({ alias_opcion: 'Mi Casa', dir_alias: 'Mi Casa', dir_predet: false });
      this.ciudadesFiltradas = [];
      this.guardando = false;
    }
  }

  get aliasEsOtro(): boolean {
    return this.form.value.alias_opcion === 'Otro';
  }

  cambiarAlias(opcion: string): void {
    this.form.patchValue({
      alias_opcion: opcion,
      dir_alias: opcion === 'Otro' ? '' : opcion,
    });
  }

  cambiarDepartamento(): void {
    const dep = Number(this.form.value.dep_id);
    this.ciudadesFiltradas = this.ciudades.filter((c) => c.ciu_depid === dep);
    this.form.patchValue({ dir_ciuid: null });
  }

  campoInvalido(campo: string): boolean {
    const c = this.form.get(campo);
    return !!c && c.invalid && (c.dirty || c.touched);
  }

  errorBackend(campo: string): string | null {
    return this.form.get(campo)?.errors?.['backend'] ?? null;
  }

  guardar(): void {
    this.form.markAllAsTouched();

    if (this.form.invalid || this.guardando) {
      return;
    }

    this.guardando = true;
    const { alias_opcion, dep_id, ...datos } = this.form.value;

    this.direccionService.crear(datos).subscribe({
      next: (resp) => {
        this.guardando = false;
        this.toastr.success(resp.message, 'Listo');
        this.guardado.emit(resp.data);
      },
      error: (e) => {
        this.guardando = false;

        if (e.status === 422 && e.error?.errors) {
          Object.entries<string[]>(e.error.errors).forEach(([campo, mensajes]) => {
            this.form.get(campo)?.setErrors({ backend: mensajes[0] });
          });
          return;
        }

        this.toastr.error('No pudimos guardar la dirección.', 'Error');
      },
    });
  }

  cerrar(): void {
    this.visibleChange.emit(false);
  }
}