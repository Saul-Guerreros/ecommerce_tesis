import { Routes } from '@angular/router';

import { authGuard } from './auth/guards/auth.guard';
import { permissionGuard } from './auth/guards/permission.guard';
import { rutaPermisoGuard } from './auth/guards/ruta-permiso.guard';


export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full'
  },

  {
    path: '',
    loadComponent: () => import('./layout').then(m => m.DefaultLayoutComponent),
    canActivate: [authGuard],
	canActivateChild: [rutaPermisoGuard], 

    data: {
      title: 'Home'
    },

    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./modules/dashboard/dashboard.module').then((m) => m.DashboardModule),
        data: { title: 'Dashboard' },
      },
      {
        path: 'reportes',
        loadChildren: () => import('./modules/reportes/reportes.module').then((m) => m.ReportesModule),
        data: { title: 'Reportes' },
      },
	    {
        path: 'perfil',
        loadChildren: () => import('./modules/perfil/perfil.module').then((m) => m.PerfilModule),
        data: { title: 'Mi perfil' },
      },

      {
      path: 'inventario/productos',
      loadChildren: () => import('./modules/productos/productos.module').then((m) => m.ProductosModule),
      data: { title: 'Productos' },
     },
	 {
      path: 'publicaciones',
      loadChildren: () => import('./views/publicaciones/publicaciones.routes').then((m) => m.routes),
      data: { title: 'Publicación Web' },
     },
      {
      path: 'categories',
      loadChildren: () => import('./modules/categories/categories.module').then(m => m.CategoriesModule),
      data: { title: 'Categorías' },
      },
      {
      path: 'brands',
      loadChildren: () => import('./modules/brands/brands.module').then(m => m.BrandsModule),
      data: { title: 'Marcas' },
      },
      {
        path: 'atributos',
        loadChildren: () => import('./views/atributos/atributos.routes').then((m) => m.ATRIBUTOS_ROUTES),
      },

      {
        path: 'usuarios',
        loadChildren: () => import('./modules/usuarios/usuarios.module').then(m => m.UsuariosModule),
        data: { title: 'Usuarios' },
      },
      
      {
        path: 'sliders',
        loadChildren: () => import('./views/sliders/sliders.routes').then((m) => m.SLIDERS_ROUTES),
      },
      {
        path: 'cupones',
        loadChildren: () => import('./views/cupones/routes').then((m) => m.routes),
      },
      
      {
        path: 'empresas',
        loadChildren: () => import('./modules/Configuracion/empresas.module').then(m => m.EmpresasModule),
        data: { title: 'Empresa' },
      },


      {
        path: 'sucursales',
        loadChildren: () => import('./modules/sucursales/sucursales.module').then(m => m.SucursalesModule),
        data: { title: 'Sucursales' },
      },

      {
        path: 'departamentos',
        loadChildren: () => import('./modules/departamentos/departamentos.module').then(m => m.DepartamentosModule),
        data: { title: 'Departamentos' },
      },
      
      {
        path: 'ciudades',
        loadChildren: () => import('./modules/ciudades/ciudades.module').then(m => m.CiudadesModule),
        data: { title: 'Ciudades' },
      },

      {
        path: 'barrios',
        loadChildren: () => import('./modules/barrios/barrios.module').then(m => m.BarriosModule),
        data: { title: 'Barrios' },
      },

      {
        path: 'calles',
        loadChildren: () => import('./modules/calles/calles.module').then(m => m.CallesModule),
        data: { title: 'Calles' },
      },

      {
        path: 'depositos',
        loadChildren: () => import('./modules/depositos/depositos.module').then(m => m.DepositosModule),
        data: { title: 'Depósitos' },
      },

      {
        path: 'timbrados',
        loadChildren: () => import('./modules/timbrados/timbrados.module').then(m => m.TimbradosModule),
        data: { title: 'Timbrados' },
      },

      {
        path: 'tipos-comprobante',
        loadChildren: () => import('./modules/tipos-comprobante/tipos-comprobante.module').then(m => m.TiposComprobanteModule),
        data: { title: 'Tipos de comprobante' },
      },

      {
        path: 'tipos-iva',
        loadChildren: () => import('./modules/tipos-iva/tipos-iva.module').then(m => m.TiposIvaModule),
        data: { title: 'Tipos de IVA' },
      },
      
      {
        path: 'proveedores',
        loadChildren: () => import('./modules/proveedores/proveedores.module').then(m => m.ProveedoresModule),
        data: { title: 'Proveedores' },
      },

      {
        path: 'tipos-proveedor',
        loadChildren: () => import('./modules/tipos-proveedor/tipos-proveedor.module').then(m => m.TiposProveedorModule),
        data: { title: 'Tipos de proveedor' },
      },
        {
        path: 'clientes',
        loadChildren: () => import('./modules/clientes/clientes.routes').then(m => m.routes),
        data: { title: 'Clientes' },
      },
      {
        path: 'tipos-cliente',
        loadChildren: () => import('./modules/tipos-cliente/tipos-cliente.module').then(m => m.TiposClienteModule),
        data: { title: 'Tipos de cliente' },
      },
      {
        path: 'unidades-medida',
        loadChildren: () => import('./modules/unidades-medida/unidades-medida.module').then(m => m.UnidadesMedidaModule),
        data: { title: 'Unidades de Medida' },
      },
      {
        path: 'funcionarios',
        loadChildren: () => import('./modules/funcionarios/funcionarios.routes').then(m => m.routes),
        data: { title: 'Funcionarios' },
      },
      {
        path: 'cargos',
        loadChildren: () => import('./modules/cargos/cargos.module').then(m => m.CargosModule),
        data: { title: 'Cargos' },
      },
      {
        path: 'tipos-documento',
        loadChildren: () => import('./modules/tipos-documento/tipos-documento.module').then(m => m.TiposDocumentoModule),
        data: { title: 'Tipos de documento' },
      },
      {
        path: 'facturas-compra',
        loadChildren: () => import('./modules/facturas-compra/facturas-compra.module').then(m => m.FacturasCompraModule),
        data: { title: 'Facturas de Compra' },
      },

      {
        path: 'facturas-venta',
        loadChildren: () =>
          import('./modules/facturas-venta/facturas-venta.module').then(m => m.FacturasVentaModule),
        data: { title: 'Facturas de Venta' },
      },

      {
        path: 'notas-credito-venta',
        loadChildren: () =>
          import('./modules/notas-credito-venta/notas-credito-venta.module')
            .then(m => m.NotasCreditoVentaModule),
        data: { title: 'Notas de Crédito de Venta' },
      },

      {
        path: 'precios',
        loadChildren: () => import('./modules/precios/precios.module').then(m => m.PreciosModule),
        data: { title: 'Gestión de Precios' },
      },

      {
        path: 'configuracion-tienda',
        loadChildren: () =>
          import('./modules/configuracion-tienda/configuracion-tienda.module').then(
            (m) => m.ConfiguracionTiendaModule
          ),
        data: { title: 'Configuración de la Tienda' },
      },

      {
        path: 'gestion-cuotas',
        loadChildren: () =>
          import('./modules/gestion-cuotas/gestion-cuotas.module').then(
            (m) => m.GestionCuotasModule
          ),
        data: { title: 'Gestión de Cuotas' },
      },
	  
	  {
        path: 'plantillas-ficha',
        loadChildren: () =>
          import('./modules/plantillas-ficha/plantillas-ficha.module').then(
            (m) => m.PlantillasFichaModule
          ),
        data: { title: 'Plantillas de Ficha Técnica' },
      },
      {
        path: 'chatbot/informacion',
        loadChildren: () => import('./modules/faq-tienda/faq-tienda.module').then(m => m.FaqTiendaModule),
        data: { title: 'Información del asistente' },
      },

      {
        path: 'inventario/ajustes',
        loadChildren: () => import('./modules/ajustes-inventario/ajustes-inventario.module').then(m => m.AjustesInventarioModule),
        data: { title: 'Ajuste de Inventario' },
      },

      {
        path: 'inventario/kardex',
        loadChildren: () => import('./modules/movimiento_stock/movimiento_stock.module').then(m => m.KardexModule),
        data: { title: 'Movimiento de Stock' },
      },
      {
        path: 'inventario/stock-actual',
        loadChildren: () => import('./modules/stock-actual/stock-actual.module').then(m => m.StockActualModule),
        data: { title: 'Stock Actual' },
      },
	  {
        path: 'inventario/inteligente',
        loadChildren: () => import('./modules/inventario-inteligente/inventario-inteligente.module').then(m => m.InventarioInteligenteModule),
        data: { title: 'Inventario inteligente' },
      },
	  {
        path: 'seguridad',
        loadChildren: () => import('./modules/seguridad/seguridad.routes').then(m => m.routes),
        data: { title: 'Seguridad' },
      },


      {
        path: 'roles',
        loadChildren: () => import('./modules/roles/roles.module').then(m => m.RolesModule),
        data: { title: 'Roles' },
      },
	  {
        path: 'permisos',
        loadComponent: () => import('./modules/permisos/permisos-matriz/permisos-matriz.component').then(m => m.PermisosMatrizComponent),
        data: { title: 'Permisos' },
      },


      {
        path: 'inventario/tipos-ajuste',
        loadChildren: () => import('./modules/tipos-ajuste/tipos-ajuste.module').then(m => m.TiposAjusteModule),
        data: { title: 'Tipos de ajuste' },
      },

      {
        path: 'configuracion-precio',
        loadChildren: () =>
          import('./modules/configuracion-precio/configuracion-precio.module').then(
            (m) => m.ConfiguracionPrecioModule
          ),
        data: { title: 'Configuración de Precios' },
      },

      {
        path: 'cuentas-por-pagar',
        loadChildren: () => import('./modules/cuentas-por-pagar/cuentas-por-pagar.module').then(m => m.CuentasPorPagarModule),
        data: { title: 'Cuentas por Pagar' },
      },

      {
        path: 'cuentas-por-cobrar',
        loadChildren: () => import('./modules/cuentas-por-cobrar/cuentas-por-cobrar.module').then(m => m.CuentasPorCobrarModule),
        data: { title: 'Cuentas por Cobrar' },
      },

      {
        path: 'libro-compra',
        loadChildren: () => import('./modules/libro-compra/libro-compra.module').then(m => m.LibroCompraModule),
        data: { title: 'Libro de Compras' },
      },

      {
        path: 'configuracion-tienda',
        loadChildren: () =>
          import('./modules/configuracion-tienda/configuracion-tienda.module').then(
            (m) => m.ConfiguracionTiendaModule
          ),
        data: { title: 'Configuración de la Tienda' },
      },

      {
        path: 'configuracion-pago',
        loadChildren: () =>
          import('./modules/configuracion-pago/configuracion-pago.module').then(
            (m) => m.ConfiguracionPagoModule
          ),
        data: { title: 'Datos de Pago' },
      },

      {
        path: 'configuracion-envio',
        loadChildren: () =>
          import('./modules/configuracion-envio/configuracion-envio.module').then(
            (m) => m.ConfiguracionEnvioModule
          ),
        data: { title: 'Configuración de Envío' },
      },

      {
        path: 'tarifas-envio',
        loadChildren: () =>
          import('./modules/tarifas-envio/tarifas-envio.module').then(
            (m) => m.TarifasEnvioModule
          ),
        data: { title: 'Tarifas de Envío' },
      },
    
      {
        path: 'pedidos',
        loadChildren: () => import('./modules/pedidos/pedidos.module').then(m => m.PedidosModule),
        canActivate: [permissionGuard('pedidos.ver')],
        data: { title: 'Pedidos' },
      },

      {                                                                    // ← PEGÁ ACÁ, inmediatamente después
        path: 'solicitudes-credito',
        loadChildren: () => import('./modules/solicitudes-credito/solicitudes-credito.module').then(m => m.SolicitudesCreditoModule),
        canActivate: [permissionGuard('solicitudes-credito.ver')],
      },

	    {
        path: 'servicios/tipos-dispositivo',
        loadChildren: () => import('./modules/tipos-dispositivo/tipos-dispositivo.module').then(m => m.TiposDispositivoModule),
        data: { title: 'Tipos de Dispositivo' },
      },
      {
        path: 'servicios/fallas',
        loadChildren: () => import('./modules/fallas/fallas.module').then(m => m.FallasModule),
        data: { title: 'Fallas' },
      },
      {
        path: 'servicios/trabajos',
        loadChildren: () => import('./modules/trabajos/trabajos.module').then(m => m.TrabajosModule),
        data: { title: 'Trabajos' },
      },
   
      {
        path: 'servicios/solicitudes',
        loadChildren: () => import('./modules/solicitudes-servicio/solicitudes-servicio.module').then(m => m.SolicitudesServicioModule),
        data: { title: 'Bandeja de solicitudes' },
      },
      {
        path: 'servicios/mis-ordenes',
        loadChildren: () => import('./modules/ordenes-tecnico/ordenes-tecnico.module').then(m => m.OrdenesTecnicoModule),
        data: { title: 'Mis órdenes' },
      },
      {
        path: 'servicios/presupuestos',
        loadChildren: () => import('./modules/presupuestos-validacion/presupuestos-validacion.module').then(m => m.PresupuestosValidacionModule),
        data: { title: 'Validación de presupuestos' },
      },
	  {
        path: 'servicios/panel',
        loadChildren: () => import('./modules/panel-servicios/panel-servicios.module').then(m => m.PanelServiciosModule),
        data: { title: 'Panel general de servicios' },
      },
      {
        path: 'servicios/cobros',
        loadChildren: () => import('./modules/cobros-servicio/cobros-servicio.module').then(m => m.CobrosServicioModule),
        data: { title: 'Cobros de servicios' },
      },
      {
        path: 'atencion-cliente/:slug',
        loadChildren: () =>
          import('./modules/paginas-informativas/paginas-informativas.module').then(m => m.PaginasInformativasModule),
        data: { title: 'Atención al Cliente' },
      },
    {
      //Fuera del FrontEnd
      path: 'discounts',
      loadChildren: () => import('./views/discounts/routes').then((m) => m.routes),
	   },
      {
        path: 'theme',
        loadChildren: () => import('./views/theme/routes').then((m) => m.routes)
      },
      {
        path: 'base',
        loadChildren: () => import('./views/base/routes').then((m) => m.routes)
      },
      {
        path: 'buttons',
        loadChildren: () => import('./views/buttons/routes').then((m) => m.routes)
      },
      {
        path: 'forms',
        loadChildren: () => import('./views/forms/routes').then((m) => m.routes)
      },
      {
        path: 'icons',
        loadChildren: () => import('./views/icons/routes').then((m) => m.routes)
      },
      {
        path: 'notifications',
        loadChildren: () => import('./views/notifications/routes').then((m) => m.routes)
      },
      {
        path: 'widgets',
        loadChildren: () => import('./views/widgets/routes').then((m) => m.routes)
      },
      {
        path: 'charts',
        loadChildren: () => import('./views/charts/routes').then((m) => m.routes)
      },
      {
        path: 'pages',
        loadChildren: () => import('./views/pages/routes').then((m) => m.routes)
      }
    ]
  },
  {
    path: '404',
    loadComponent: () => import('./views/pages/page404/page404.component').then(m => m.Page404Component),
    data: {
      title: 'Page 404'
    }
  },
  {
    path: '500',
    loadComponent: () => import('./views/pages/page500/page500.component').then(m => m.Page500Component),
    data: {
      title: 'Page 500'
    }
  },
  {
    path: 'login',
    loadComponent: () => import('./views/pages/login/login.component').then(m => m.LoginComponent),
    data: {
      title: 'Login Page'
    }
  },

  {
    path: 'forgot-password',
    loadComponent: () => import('./views/pages/forgot-password/forgot-password.component').then(m => m.ForgotPasswordComponent),
    data: {
      title: 'Forgot Password'
    }
  },

  {
    path: 'reset-password',
    loadComponent: () => import('./views/pages/reset-password/reset-password.component').then(m => m.ResetPasswordComponent),
    data: {
      title: 'Reset Password'
    }
  },

{
  path: 'register',
  loadComponent: () => import('./views/pages/register/register.component').then(m => m.RegisterComponent),
  canActivate: [authGuard, permissionGuard('usuarios.gestionar')],
  data: {
    title: 'Register Page'
  }
},

  { path: '**', redirectTo: 'dashboard' }
];
