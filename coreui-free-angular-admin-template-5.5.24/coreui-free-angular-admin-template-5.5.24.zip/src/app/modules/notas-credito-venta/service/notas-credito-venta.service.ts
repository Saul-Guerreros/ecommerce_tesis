import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import {
  ConfigPorFactura, NotaCreditoVenta, NotaCreditoVentaConfig,
  NotaCreditoVentaFiltros, NotaCreditoVentaInput,
} from '../models/nota-credito-venta.model';
import { environment } from '../../../../environments/environment';

/**
 * Dos prefijos, una sola tabla:
 *   /admin/notas-credito-venta      → el módulo propio (listado completo)
 *   /admin/facturas-venta/{id}/...  → el atajo dentro del detalle de la factura
 *
 * Sin update(): un comprobante fiscal emitido no se edita, se anula.
 */
@Injectable({ providedIn: 'root' })
export class NotasCreditoVentaService {
  private apiUrl     = `${environment.apiUrl}/admin/notas-credito-venta`;
  private facturaUrl = `${environment.apiUrl}/admin/facturas-venta`;

  constructor(private http: HttpClient) {}

  getAll(filtros: NotaCreditoVentaFiltros = {}): Observable<NotaCreditoVenta[]> {
    let params = new HttpParams();
    if (filtros.search)   params = params.set('search', filtros.search);
    if (filtros.estado)   params = params.set('estado', filtros.estado);
    if (filtros.motivo)   params = params.set('motivo', filtros.motivo);
    if (filtros.sucursal) params = params.set('sucursal', filtros.sucursal);
    if (filtros.desde)    params = params.set('desde', filtros.desde);
    if (filtros.hasta)    params = params.set('hasta', filtros.hasta);

    return this.http.get<{ data: NotaCreditoVenta[] }>(this.apiUrl, { params })
      .pipe(map((res) => res.data));
  }

  getConfig(): Observable<NotaCreditoVentaConfig> {
    return this.http.get<NotaCreditoVentaConfig>(`${this.apiUrl}/config`);
  }

  getById(id: number): Observable<NotaCreditoVenta> {
    return this.http.get<{ data: NotaCreditoVenta }>(`${this.apiUrl}/${id}`)
      .pipe(map((res) => res.data));
  }

  create(nota: NotaCreditoVentaInput): Observable<any> {
    return this.http.post(this.apiUrl, nota);
  }

  anular(id: number, motivo?: string | null): Observable<any> {
    return this.http.patch(`${this.apiUrl}/${id}/anular`, { motivo: motivo ?? null });
  }

  // ---------- Atajo desde la factura ----------

  getConfigPorFactura(venId: number): Observable<ConfigPorFactura> {
    return this.http.get<ConfigPorFactura>(`${this.facturaUrl}/${venId}/notas-credito/config`);
  }

  getPorFactura(venId: number): Observable<NotaCreditoVenta[]> {
    return this.http.get<{ data: NotaCreditoVenta[] }>(`${this.facturaUrl}/${venId}/notas-credito`)
      .pipe(map((res) => res.data));
  }
}