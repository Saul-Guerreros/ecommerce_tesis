import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Subject, debounceTime, distinctUntilChanged } from 'rxjs';
import {
  BadgeModule, ButtonModule, CardModule, FormModule, ModalModule, SpinnerModule, TableModule,
} from '@coreui/angular';
import {
  EstadoOption, MotivoNotaCredito, NotaCreditoVenta, SucursalOption,
} from '../models/nota-credito-venta.model';
import { NotasCreditoVentaService } from '../service/notas-credito-venta.service';
import { FormNotaCreditoVentaComponent } from '../form-nota-credito-venta/form-nota-credito-venta.component';
import { VerNotaCreditoVentaComponent } from '../ver-nota-credito-venta/ver-nota-credito-venta.component';

@Component({
  selector: 'app-list-nota-credito-venta',
  standalone: true,
  imports: [
    CommonModule, FormsModule, CardModule, TableModule, ButtonModule, BadgeModule,
    SpinnerModule, FormModule, ModalModule,
    FormNotaCreditoVentaComponent, VerNotaCreditoVentaComponent,
  ],
  templateUrl: './list-nota-credito-venta.component.html',
})
export class ListNotaCreditoVentaComponent implements OnInit {
  notas: NotaCreditoVenta[] = [];
  motivos: MotivoNotaCredito[] = [];
  estados: EstadoOption[] = [];
  sucursales: SucursalOption[] = [];

  cargando = false;
  cargandoVer = false;

  search = '';
  filtroEstado = '';
  filtroMotivo = '';
  filtroSucursal = '';
  filtroDesde = '';
  filtroHasta = '';

  private searchSubject = new Subject<string>();

  formVisible = false;
  verVisible = false;
  notaSeleccionada: NotaCreditoVenta | null = null;

  anularVisible = false;
  notaAAnular: NotaCreditoVenta | null = null;
  motivoAnulacion = '';
  anulando = false;

  constructor(private service: NotasCreditoVentaService, private toastr: ToastrService) {}

  ngOnInit(): void {
    this.cargar();

    this.service.getConfig().subscribe({
      next: (res) => {
        this.motivos = res.motivos ?? [];
        this.estados = res.estados ?? [];
        this.sucursales = res.sucursales ?? [];
      },
      error: () => {},
    });

    this.searchSubject
      .pipe(debounceTime(400), distinctUntilChanged())
      .subscribe(() => this.cargar());
  }

  onSearchChange(): void {
    this.searchSubject.next(this.search);
  }

  cargar(): void {
    this.cargando = true;

    this.service.getAll({
      search: this.search,
      estado: this.filtroEstado,
      motivo: this.filtroMotivo,
      sucursal: this.filtroSucursal,
      desde: this.filtroDesde,
      hasta: this.filtroHasta,
    }).subscribe({
      next: (res) => { this.notas = res; this.cargando = false; },
      error: () => {
        this.toastr.error('No se pudieron cargar las notas de crédito', 'Error');
        this.cargando = false;
      },
    });
  }

  limpiarFiltros(): void {
    this.search = '';
    this.filtroEstado = '';
    this.filtroMotivo = '';
    this.filtroSucursal = '';
    this.filtroDesde = '';
    this.filtroHasta = '';
    this.cargar();
  }

  abrirNueva(): void {
    this.formVisible = true;
  }

  /** El listado no trae el detalle: se pide la NC completa al abrir el modal. */
  abrirVer(n: NotaCreditoVenta): void {
    this.cargandoVer = true;

    this.service.getById(n.ncv_id).subscribe({
      next: (completa) => {
        this.notaSeleccionada = completa;
        this.verVisible = true;
        this.cargandoVer = false;
      },
      error: () => {
        this.toastr.error('No se pudo cargar el detalle de la nota de crédito', 'Error');
        this.cargandoVer = false;
      },
    });
  }

  pedirAnular(n: NotaCreditoVenta): void {
    this.notaAAnular = n;
    this.motivoAnulacion = '';
    this.anularVisible = true;
  }

  cancelarAnular(): void {
    this.anularVisible = false;
    this.notaAAnular = null;
  }

  confirmarAnular(): void {
    if (!this.notaAAnular || this.anulando) return;

    this.anulando = true;

    this.service.anular(this.notaAAnular.ncv_id, this.motivoAnulacion).subscribe({
      next: (res) => {
        this.toastr.success(res?.message ?? 'Nota de crédito anulada', 'Éxito');
        this.anularVisible = false;
        this.verVisible = false;
        this.anulando = false;
        this.cargar();
      },
      error: (err) => {
        this.toastr.error(err?.error?.message ?? 'No se pudo anular la nota de crédito', 'Error');
        this.anulando = false;
      },
    });
  }

  colorEstado(estado: number): string {
    return estado === 9 ? 'secondary' : 'success';
  }

  textoEstado(estado: number): string {
    return this.estados.find((e) => e.valor === estado)?.descripcion ?? '—';
  }

  identificacion(n: NotaCreditoVenta): string {
    return n.ncv_ruc ? `RUC ${n.ncv_ruc}` : `CI ${n.ncv_ci}`;
  }
}