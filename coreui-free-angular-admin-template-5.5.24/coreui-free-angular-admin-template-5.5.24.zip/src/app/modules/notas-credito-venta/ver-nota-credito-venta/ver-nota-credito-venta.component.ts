import { Component, EventEmitter, Input, Output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BadgeModule, ButtonModule, FormModule, ModalModule, TableModule } from '@coreui/angular';
import { DetNotaCreditoVenta, NotaCreditoVenta } from '../models/nota-credito-venta.model';

/**
 * Vista de solo lectura. No hay modo edición y no es un descuido: una NC
 * emitida es un comprobante fiscal inmutable. Si está mal, se anula.
 */
@Component({
  selector: 'app-ver-nota-credito-venta',
  standalone: true,
  imports: [CommonModule, ModalModule, ButtonModule, TableModule, BadgeModule, FormModule],
  templateUrl: './ver-nota-credito-venta.component.html',
})
export class VerNotaCreditoVentaComponent {
  @Input() visible = false;
  @Input() nota: NotaCreditoVenta | null = null;

  @Output() visibleChange = new EventEmitter<boolean>();
  @Output() anular = new EventEmitter<NotaCreditoVenta>();

  get detalle(): DetNotaCreditoVenta[] {
    return this.nota?.detalle ?? [];
  }

  get esAnulada(): boolean {
    return this.nota?.ncv_estado === 9;
  }

  get identificacion(): string {
    if (!this.nota) return '';
    return this.nota.ncv_ruc ? `RUC ${this.nota.ncv_ruc}` : `CI ${this.nota.ncv_ci}`;
  }

  /** Columna Exentas / 5% / 10% del renglón impreso, igual que en la factura. */
  columna(item: DetNotaCreditoVenta, tasa: number): number | null {
    return Number(item.dnv_tasa) === tasa ? Number(item.dnv_valorventa) : null;
  }

  cerrar(): void {
    this.visible = false;
    this.visibleChange.emit(false);
  }

  pedirAnular(): void {
    if (this.nota) this.anular.emit(this.nota);
  }
}