import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { TipoAjuste } from '../models/tipo-ajuste.model';
import { environment } from '../../../../environments/environment';

@Injectable({ providedIn: 'root' })
export class TiposAjusteService {
  private apiUrl = `${environment.apiUrl}/admin/tipos-ajuste`;

  constructor(private http: HttpClient) {}

  getAll(filtros: { search?: string; estado?: string } = {}): Observable<TipoAjuste[]> {
    let params = new HttpParams();
    if (filtros.search) params = params.set('search', filtros.search);
    if (filtros.estado !== undefined && filtros.estado !== '') params = params.set('estado', filtros.estado);
    return this.http.get<{ data: TipoAjuste[] }>(this.apiUrl, { params }).pipe(map((res) => res.data));
  }

  create(tipo: Partial<TipoAjuste>): Observable<any> { return this.http.post(this.apiUrl, tipo); }
  update(id: number, tipo: Partial<TipoAjuste>): Observable<any> { return this.http.put(`${this.apiUrl}/${id}`, tipo); }
  delete(id: number): Observable<any> { return this.http.delete(`${this.apiUrl}/${id}`); }
  toggleEstado(id: number): Observable<any> { return this.http.patch(`${this.apiUrl}/${id}/estado`, {}); }
}