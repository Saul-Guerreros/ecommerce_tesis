import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

import { PedidoFiltros, PedidosConfig, PedidosPaginados } from '../models/pedido.model';

import {
  ActualizarChequePayload, DescartarChequePayload, GestionConfig,
  MotivoRechazo, PedidoDetalle, RechazarChequePayload, RechazarPagoPayload,
  RecibirChequePayload, RegistrarCobroPayload, ValidarComprobantePayload,
} from '../models/pedido-detalle.model';

import { environment } from '../../../../environments/environment';

/**
 * Sin headers manuales: el token JWT lo agrega auth.interceptor.ts,
 * registrado globalmente en app.config.ts.
 */
@Injectable({ providedIn: 'root' })
export class PedidosService {
  private apiUrl = `${environment.apiUrl}/admin/pedidos`;

  constructor(private http: HttpClient) {}

  // ---------- Bandeja ----------

  list(filtros: PedidoFiltros): Observable<PedidosPaginados> {
    return this.http.get<PedidosPaginados>(this.apiUrl, {
      params: this.construirParams(filtros),
    });
  }

  config(): Observable<PedidosConfig> {
    return this.http.get<PedidosConfig>(`${this.apiUrl}/config`);
  }

  exportar(filtros: PedidoFiltros): Observable<Blob> {
    const { page, per_page, ...sinPaginacion } = filtros;

    return this.http.get(`${this.apiUrl}/exportar`, {
      params: this.construirParams(sinPaginacion),
      responseType: 'blob',
    });
  }

  // ---------- Gestión del pedido ----------

  show(pedidoId: number): Observable<{ data: PedidoDetalle }> {
    return this.http.get<{ data: PedidoDetalle }>(`${this.apiUrl}/${pedidoId}`);
  }

  /** Catálogos de los modales de rechazo y parámetros del cheque. */
  configGestion(): Observable<GestionConfig> {
    return this.http.get<GestionConfig>(`${this.apiUrl}/gestion/config`);
  }

  /** Paso 1: el admin da por bueno el comprobante. No mueve dinero. */
  validarComprobante(
    pedidoId: number,
    pagoId: number,
    payload: ValidarComprobantePayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/comprobante/validar`,
      payload,
    );
  }

  /**
  * Paso 2: emite la factura del pedido y programa su declaración a la
  * DNIT. Sin payload: los datos fiscales salen del pedido.
  */
  generarFactura(pedidoId: number): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/factura/generar`,
      {},
    );
  }

  /** Paso 3: entra la plata. Se registra contra la factura del pedido. */
  registrarCobro(
    pedidoId: number,
    pagoId: number,
    payload: RegistrarCobroPayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/cobrar`,
      payload,
    );
  }

  rechazarPago(
    pedidoId: number,
    pagoId: number,
    payload: RechazarPagoPayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/rechazar`,
      payload,
    );
  }

  cambiarEstado(
    pedidoId: number,
    estado: string,
    comentario?: string | null,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.patch<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/estado`,
      { estado, comentario: comentario ?? null },
    );
  }

    // ---------- Cheques ----------

  /** [Editar]: corrige los datos contra el papel que tiene el admin. */
  actualizarCheque(
    pedidoId: number,
    pagoId: number,
    payload: ActualizarChequePayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.put<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/cheque`,
      payload,
    );
  }

  /** [Descartar cheque]: borra la declaración del checkout. No cancela el pedido. */
  descartarCheque(
    pedidoId: number,
    pagoId: number,
    payload: DescartarChequePayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/cheque/descartar`,
      payload,
    );
  }

  /**
   * [Confirmar recepción]: el equivalente de validar el comprobante, pero
   * con efectos reales. Según la política configurada, descuenta stock y
   * deja el pedido listo para entrega.
   */
  recibirCheque(
    pedidoId: number,
    pagoId: number,
    payload: RecibirChequePayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/cheque/recibir`,
      payload,
    );
  }

  /** [Rechazar cheque]: cancela el pedido y libera la reserva. */
  rechazarCheque(
    pedidoId: number,
    pagoId: number,
    payload: RechazarChequePayload,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/cheque/rechazar`,
      payload,
    );
  }

  // ---------- Auxiliar ----------

  private construirParams(filtros: PedidoFiltros): HttpParams {
    let params = new HttpParams();

    Object.entries(filtros).forEach(([clave, valor]) => {
      if (valor === null || valor === undefined) return;

      const texto = String(valor).trim();
      if (texto === '') return;

      params = params.set(clave, texto);
    });

    return params;
  }
  
  
   /** Reenvía la factura electrónica aprobada por el canal indicado. Devuelve el pedido actualizado. */
  reenviarFactura(
    pedidoId: number,
    canal: 'CORREO' | 'WHATSAPP',
    destino?: string | null,
  ): Observable<{ message: string; data: PedidoDetalle }> {
    return this.http.post<{ message: string; data: PedidoDetalle }>(
      `${this.apiUrl}/${pedidoId}/factura/reenviar`,
      { canal, destino: destino || null },
    );
  }

  /** KuDE (PDF) de la factura del pedido: se adjunta a mano en el envío por WhatsApp. */
  kudeFactura(pedidoId: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}/${pedidoId}/factura/kude`, { responseType: 'blob' });
  }


  /** El comprobante se trae como blob porque la ruta exige token JWT. */
    comprobante(pedidoId: number, pagoId: number): Observable<Blob> {
    return this.http.get(
        `${this.apiUrl}/${pedidoId}/pagos/${pagoId}/comprobante`,
        { responseType: 'blob' },
    );
    }

}